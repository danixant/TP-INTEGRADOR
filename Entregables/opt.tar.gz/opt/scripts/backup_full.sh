#!/bin/bash

# --- Constante de Destino por Defecto ---
DESTINO_BASE="/backup_dir"

# --- Función de Ayuda (-help) ---
mostrar_ayuda() {
    echo "Uso: $0 [OPCION] [ORIGEN]"
    echo ""
    echo "Script de backup para el TP Integrador."
    echo ""
    echo "OPCIONES:"
    echo "  -h, -help    Muestra este mensaje de ayuda."
    echo ""
    echo "ARGUMENTOS:"
    echo "  ORIGEN       Directorio que se desea backupear (ej: /var/log)"
    echo ""
    echo "El destino del backup será siempre $DESTINO_BASE"
}

# --- 1. Validar Argumento de Ayuda ---
if [ "$1" == "-h" ] || [ "$1" == "-help" ]; then
    mostrar_ayuda
    exit 0
fi

# --- 2. Validar Argumento de Origen ---
ORIGEN=$1
if [ -z "$ORIGEN" ]; then
    echo "Error: Debe especificar un directorio de origen."
    echo "Use -h para ver la ayuda."
    exit 1
fi

# --- 3. Validar que Origen y Destino existan (Validación de FS) ---
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 1
fi

if [ ! -d "$DESTINO_BASE" ]; then
    echo "Error: El directorio de destino '$DESTINO_BASE' no está montado o no existe."
    exit 1
fi

# --- 4. Crear Nombre del Archivo de Backup ---
# Formato YYYYMMDD (ANSI)
FECHA=$(date +"%Y%m%d")

# Limpiamos el nombre del origen (ej: /var/log -> var_log)
NOMBRE_LIMPIO=$(echo $ORIGEN | sed 's|^/||' | tr '/' '_')

# Nombre final (ej: log_bkp_20240302.tar.gz)
NOMBRE_FINAL="${NOMBRE_LIMPIO}_bkp_${FECHA}.tar.gz"
DESTINO_FINAL="$DESTINO_BASE/$NOMBRE_FINAL"

# --- 5. Ejecutar el Backup ---
echo "Iniciando backup de $ORIGEN..."

# Usamos tar para comprimir
# c = crear, z = comprimir (gzip), f = archivo
tar -czf "$DESTINO_FINAL" "$ORIGEN"

echo "Backup completado: $DESTINO_FINAL"

exit 0
